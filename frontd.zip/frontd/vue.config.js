module.exports = {
    runtimeCompiler: true
}