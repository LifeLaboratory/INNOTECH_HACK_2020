<template>
  <div class="about">
    Введите ссылку на VK человека
     <a-input placeholder=""  style="margin-left: 50px; margin-rigth: 50px; margin-top: 20px; margin-bottom: 20px"/>
     <a-button type="primary">
      Поиск
    </a-button>
  </div>
</template>
